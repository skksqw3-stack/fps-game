package com.example.android4fps

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class FpsRenderer : GLSurfaceView.Renderer {
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private var program = 0
    private var position = 0
    private var color = 0
    private var mvp = 0
    @Volatile private var yaw = 0f
    @Volatile private var pitch = 0f
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 4f
    @Volatile private var shotFlash = 0
    private var enemyX = floatArrayOf(-2.2f, 1.8f, 0.4f)
    private var enemyZ = floatArrayOf(-8f, -11f, -15f)
    private val cube = makeCube()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.35f, 0.48f, 0.58f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        val vs = "uniform mat4 uMVP; attribute vec3 aPos; void main(){ gl_Position=uMVP*vec4(aPos,1.0); }"
        val fs = "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }"
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(program, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(program)
        position = GLES20.glGetAttribLocation(program, "aPos")
        color = GLES20.glGetUniformLocation(program, "uColor")
        mvp = GLES20.glGetUniformLocation(program, "uMVP")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(projection, 0, 68f, width.toFloat()/height.coerceAtLeast(1), 0.1f, 100f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val angle = Math.toRadians(yaw.toDouble())
        Matrix.setLookAtM(view, 0, playerX, 1.65f, playerZ,
            playerX + sin(angle).toFloat()*10f, 1.65f + pitch/80f,
            playerZ - cos(angle).toFloat()*10f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
        GLES20.glUseProgram(program)
        // Ground, road and simple urban cover
        drawBox(0f,-0.15f,-8f, 18f,0.25f,42f, 0.28f,0.30f,0.29f)
        drawBox(0f,-0.01f,-8f, 5.5f,0.03f,42f, 0.12f,0.13f,0.14f)
        for (i in -2..2) {
            drawBox(i*5f, 2.2f, -10f, 2.8f,4.5f,2.8f, 0.34f,0.36f,0.38f)
            drawBox(i*5f, 2.8f, -20f, 3.2f,5.6f,3.0f, 0.40f,0.38f,0.34f)
        }
        // Enemy targets
        for (i in enemyX.indices) {
            drawBox(enemyX[i],1.05f,enemyZ[i],0.58f,1.0f,0.42f,0.42f,0.20f,0.16f)
            drawBox(enemyX[i],1.85f,enemyZ[i],0.42f,0.42f,0.42f,0.72f,0.58f,0.46f)
            drawBox(enemyX[i]-0.38f,0.95f,enemyZ[i],0.18f,0.85f,0.20f,0.32f,0.31f,0.30f)
            drawBox(enemyX[i]+0.38f,0.95f,enemyZ[i],0.18f,0.85f,0.20f,0.32f,0.31f,0.30f)
        }
        // First-person weapon at lower-right of view
        drawBox(0.42f,1.22f,3.15f,0.18f,0.18f,0.75f,0.12f,0.13f,0.14f)
        drawBox(0.42f,1.08f,2.85f,0.22f,0.28f,0.24f,0.18f,0.19f,0.20f)
        if (shotFlash > 0) shotFlash--
    }

    fun rotate(dx: Float, dy: Float) {
        yaw = (yaw + dx).coerceIn(-65f,65f)
        pitch = (pitch - dy).coerceIn(-35f,35f)
    }

    fun move(dx: Float, dy: Float) {
        val angle = Math.toRadians(yaw.toDouble())
        playerX += (cos(angle).toFloat() * dx + sin(angle).toFloat() * dy)
        playerZ += (sin(angle).toFloat() * dx - cos(angle).toFloat() * dy)
        playerX = playerX.coerceIn(-7f, 7f)
        playerZ = playerZ.coerceIn(-4f, 12f)
    }

    fun fire() {
        shotFlash = 5
        // Simple center-aim hit test; successful hits remove a target.
        if (enemyX.isNotEmpty()) {
            val idx = enemyZ.indices.minBy { kotlin.math.abs(enemyX[it] - sin(Math.toRadians(yaw.toDouble())).toFloat()*3f) }
            enemyX[idx] = 1000f
        }
    }

    private fun drawBox(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float) {
        Matrix.setIdentityM(model,0)
        Matrix.translateM(model,0,x,y,z)
        Matrix.scaleM(model,0,sx,sy,sz)
        val out=FloatArray(16)
        Matrix.multiplyMM(out,0,vp,0,model,0)
        GLES20.glUniformMatrix4fv(mvp,1,false,out,0)
        GLES20.glUniform4f(color,r,g,b,1f)
        cube.position(0)
        GLES20.glEnableVertexAttribArray(position)
        GLES20.glVertexAttribPointer(position,3,GLES20.GL_FLOAT,false,0,cube)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36)
    }

    private fun shader(type:Int,src:String):Int {
        val s=GLES20.glCreateShader(type)
        GLES20.glShaderSource(s,src); GLES20.glCompileShader(s)
        return s
    }

    private fun makeCube():FloatBuffer {
        val v=floatArrayOf(
            -1f,-1f,1f, 1f,-1f,1f, 1f,1f,1f, -1f,-1f,1f, 1f,1f,1f, -1f,1f,1f,
            1f,-1f,-1f, -1f,-1f,-1f, -1f,1f,-1f, 1f,-1f,-1f, -1f,1f,-1f, 1f,1f,-1f,
            -1f,-1f,-1f, -1f,-1f,1f, -1f,1f,1f, -1f,-1f,-1f, -1f,1f,1f, -1f,1f,-1f,
            1f,-1f,1f, 1f,-1f,-1f, 1f,1f,-1f, 1f,-1f,1f, 1f,1f,-1f, 1f,1f,1f,
            -1f,1f,1f, 1f,1f,1f, 1f,1f,-1f, -1f,1f,1f, 1f,1f,-1f, -1f,1f,-1f,
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,-1f,1f, -1f,-1f,-1f, 1f,-1f,1f, -1f,-1f,1f
        )
        val bb=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder())
        val fb=bb.asFloatBuffer(); fb.put(v); fb.position(0); return fb
    }
}
