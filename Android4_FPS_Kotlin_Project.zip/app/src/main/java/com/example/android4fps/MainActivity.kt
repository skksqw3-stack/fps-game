package com.example.android4fps

import android.app.Activity
import android.os.Bundle
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var game: GameView
    private lateinit var hud: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        game = GameView(this)
        val root = FrameLayout(this)
        root.addView(game)
        hud = TextView(this)
        hud.text = "FPS 3D  •  WASD: move   |   touch: look   |   FIRE: shoot"
        hud.setTextColor(Color.WHITE)
        hud.textSize = 13f
        hud.setShadowLayer(3f, 1f, 1f, Color.BLACK)
        val hp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT)
        hp.setMargins(14, 10, 10, 10)
        root.addView(hud, hp)
        val fire = TextView(this)
        fire.text = "FIRE"
        fire.textSize = 18f
        fire.gravity = Gravity.CENTER
        fire.setTextColor(Color.WHITE)
        fire.setBackgroundColor(0xAA9B2525.toInt())
        val fp = FrameLayout.LayoutParams(116, 116, Gravity.RIGHT or Gravity.BOTTOM)
        fp.setMargins(10, 10, 28, 26)
        root.addView(fire, fp)
        fire.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) game.shoot()
            true
        }
        root.setOnTouchListener { _, e ->
            if (e.pointerCount > 0 && e.action == MotionEvent.ACTION_MOVE) {
                game.look(e.x, e.y)
            }
            true
        }
        setContentView(root)
    }

    override fun onPause() { super.onPause(); game.onPause() }
    override fun onResume() { super.onResume(); game.onResume() }
}

class GameView(activity: Activity) : GLSurfaceView(activity) {
    private val rendererGame = FpsRenderer()
    private var lastX = 0f
    private var lastY = 0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(rendererGame)
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    if (lastX < width * 0.48f) {
                        rendererGame.move(dx * 0.012f, dy * 0.012f)
                    } else {
                        rendererGame.rotate(dx * 0.18f, dy * 0.12f)
                    }
                    lastX = e.x; lastY = e.y
                }
            }
            true
        }
    }
    fun shoot() { rendererGame.fire() }
    fun look(x: Float, y: Float) { }
}
